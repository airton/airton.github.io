/* Popup controller — injeta funções na aba ativa via chrome.scripting */

const els = {
  scan: document.getElementById("scan"),
  download: document.getElementById("download"),
  autoscroll: document.getElementById("autoscroll"),
  aszip: document.getElementById("aszip"),
  delay: document.getElementById("delay"),
  status: document.getElementById("status"),
  barWrap: document.getElementById("barWrap"),
  bar: document.getElementById("bar"),
};

let found = [];

function setStatus(msg, kind = "") {
  els.status.textContent = msg;
  els.status.className = "status" + (kind ? " " + kind : "");
}

function setProgress(done, total) {
  els.barWrap.style.display = total ? "block" : "none";
  els.bar.style.width = total ? `${Math.round((done / total) * 100)}%` : "0%";
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

/* ---- Funções injetadas na página (executadas no contexto da aba) ---- */

// Coleta as URLs de redirecionamento de mídia já carregadas
function pageScan() {
  const urls = performance
    .getEntriesByType("resource")
    .filter((r) => r.name.includes("getMediaUrlRedirect"))
    .map((r) => r.name);
  return [...new Set(urls)];
}

// Rola a página até parar de surgir novas imagens, devolve a contagem final
async function pageAutoScroll() {
  const count = () =>
    new Set(
      performance
        .getEntriesByType("resource")
        .filter((r) => r.name.includes("getMediaUrlRedirect"))
        .map((r) => r.name)
    ).size;

  let stable = 0;
  let last = count();
  while (stable < 3) {
    window.scrollTo(0, document.body.scrollHeight);
    // alguns layouts usam um container rolável próprio
    document.querySelectorAll("*").forEach((el) => {
      if (el.scrollHeight > el.clientHeight + 50) el.scrollTop = el.scrollHeight;
    });
    await new Promise((r) => setTimeout(r, 800));
    const now = count();
    stable = now === last ? stable + 1 : 0;
    last = now;
  }
  return last;
}

// Faz o download de todas as URLs, reportando progresso por chrome.runtime
async function pageDownload(urls, delay) {
  let ok = 0;
  let fail = 0;
  for (let i = 0; i < urls.length; i++) {
    const url = urls[i];
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error("HTTP " + response.status);
      const blob = await response.blob();

      const params = new URLSearchParams(url.split("?")[1] || "");
      const baseName = params.get("name") || `image-${i + 1}`;
      const ext = (blob.type && blob.type.split("/")[1]) || "png";

      const a = document.createElement("a");
      const objectUrl = URL.createObjectURL(blob);
      a.href = objectUrl;
      a.download = `${baseName}.${ext}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(objectUrl), 4000);
      ok++;
    } catch (e) {
      fail++;
      console.error(`[GeminiFlow] Erro ao baixar ${url}:`, e);
    }
    chrome.runtime.sendMessage({
      type: "progress",
      done: i + 1,
      total: urls.length,
      ok,
      fail,
    });
    if (delay > 0) await new Promise((r) => setTimeout(r, delay));
  }
  return { ok, fail };
}

// Faz o download de todas as URLs empacotadas em um único .zip (requer JSZip
// já injetado no mesmo mundo isolado)
async function pageDownloadZip(urls) {
  if (typeof JSZip === "undefined") {
    throw new Error("JSZip não foi carregado na página.");
  }
  const zip = new JSZip();
  const used = {};
  let ok = 0;
  let fail = 0;

  for (let i = 0; i < urls.length; i++) {
    const url = urls[i];
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error("HTTP " + response.status);
      const blob = await response.blob();

      const params = new URLSearchParams(url.split("?")[1] || "");
      let baseName = params.get("name") || `image-${i + 1}`;
      const ext = (blob.type && blob.type.split("/")[1]) || "png";
      let fileName = `${baseName}.${ext}`;
      // evita nomes duplicados dentro do zip
      if (used[fileName]) {
        fileName = `${baseName}-${used[fileName]++}.${ext}`;
      } else {
        used[fileName] = 1;
      }
      zip.file(fileName, blob);
      ok++;
    } catch (e) {
      fail++;
      console.error(`[GeminiFlow] Erro ao baixar ${url}:`, e);
    }
    chrome.runtime.sendMessage({
      type: "progress",
      done: i + 1,
      total: urls.length,
      ok,
      fail,
      phase: "fetch",
    });
  }

  chrome.runtime.sendMessage({ type: "progress", done: urls.length, total: urls.length, ok, fail, phase: "zip" });
  const content = await zip.generateAsync({ type: "blob" });
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
  const objectUrl = URL.createObjectURL(content);
  const a = document.createElement("a");
  a.href = objectUrl;
  a.download = `gemini-flow-images-${stamp}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(objectUrl), 8000);

  return { ok, fail };
}

/* ---- Ações do popup ---- */

async function runInPage(func, args = []) {
  const tab = await getActiveTab();
  const [res] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func,
    args,
    world: "ISOLATED",
  });
  return res.result;
}

async function injectLib(file) {
  const tab = await getActiveTab();
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: [file],
    world: "ISOLATED",
  });
}

async function handleScan() {
  els.scan.disabled = true;
  setProgress(0, 0);
  try {
    if (els.autoscroll.checked) {
      setStatus("Rolando a página para carregar imagens…");
      await runInPage(pageAutoScroll);
    }
    setStatus("Procurando imagens…");
    found = await runInPage(pageScan);

    if (!found || found.length === 0) {
      setStatus(
        "Nenhuma imagem encontrada. Role a página manualmente até as imagens aparecerem e tente de novo.",
        "err"
      );
      els.download.disabled = true;
    } else {
      setStatus(`${found.length} imagem(ns) encontrada(s). Pronto para baixar.`, "ok");
      els.download.disabled = false;
    }
  } catch (e) {
    setStatus("Erro ao escanear: " + e.message + "\nVerifique se está na aba do Gemini/Flow.", "err");
  } finally {
    els.scan.disabled = false;
  }
}

async function handleDownload() {
  if (!found.length) return;
  els.scan.disabled = true;
  els.download.disabled = true;
  const delay = Math.max(0, parseInt(els.delay.value, 10) || 0);
  setStatus(`Baixando ${found.length} imagem(ns)…`);
  setProgress(0, found.length);
  try {
    let result;
    if (els.aszip.checked) {
      await injectLib("lib/jszip.min.js");
      result = await runInPage(pageDownloadZip, [found]);
    } else {
      result = await runInPage(pageDownload, [found, delay]);
    }
    const { ok, fail } = result;
    setStatus(
      `Concluído: ${ok} imagem(ns)` +
        (els.aszip.checked ? " no .zip" : " baixada(s)") +
        (fail ? `, ${fail} falha(s).` : "."),
      fail ? "err" : "ok"
    );
  } catch (e) {
    setStatus("Erro durante o download: " + e.message, "err");
  } finally {
    els.scan.disabled = false;
    els.download.disabled = false;
  }
}

// Progresso vindo da página
chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "progress") {
    setProgress(msg.done, msg.total);
    if (msg.phase === "zip") {
      setStatus(`Compactando ${msg.ok} imagem(ns) no .zip…`);
    } else {
      setStatus(`Baixando ${msg.done}/${msg.total}…  (${msg.ok} ok, ${msg.fail} falha)`);
    }
  }
});

els.scan.addEventListener("click", handleScan);
els.download.addEventListener("click", handleDownload);
